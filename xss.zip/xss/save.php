<?php
if(!empty($_GET['data'])) {
    $logfile = fopen('data.txt', 'a+');
    fwrite($logfile, $_GET['data']);
    fclose($logfile);
}
?>