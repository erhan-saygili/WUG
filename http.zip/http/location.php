<?php
//header('Location: http://localhost/http/index.php');
header('Location: http://localhost/http/index.php', true, 301);
?>