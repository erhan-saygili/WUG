<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>HTTP Lab.</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <br>
    <br>
    <br>
    <div id='browser'>
        <div id='browser-bar'>
            <div class='circles'></div>
            <div class='circles'></div>
            <div class='circles'></div>
            <p><b>HTTP Lab.</b></p>
        </div>
        <div id='content'>
            <div id='left'>
                <ul id='location-bar'>
                    <li>
                        <a class='location' href="index.php"><b>Ana Sayfa</b></a>
                    </li>
                    <li>
                        <a class='location' href="get.php"><b>GET Method</b></a>
                    </li>
                    <li>
                        <a class='location' href="post.php"><b>POST Method</b></a>
                    </li>
                </ul>
                <center><img src="images/logo.png" alt="Logo"></center>
				<?php
					if (!isset($_SERVER['PHP_AUTH_USER'])) {
					header('WWW-Authenticate: Basic realm="Gizli Belge"');
					header('HTTP/1.0 401 Unauthorized');
					exit;
					} else {
						echo "<p>Merhaba {$_SERVER['PHP_AUTH_USER']}.</p>";
						echo "<p>Girdiğiniz Şifre : {$_SERVER['PHP_AUTH_PW']} </p>";
					}
				?>
            </div>

            <div id='right'>

                <p><b>BAŞLIK PARAMETRELERİ</b></p>
				
				<ol type="1">
				  <li><a href="host.php">Host</a></li>
				  <li><a href="user-agent.php">User-Agent</a></li>
				  <li><a href="accept-language.php">Accept-Language</a></li>
				  <li><a href="accept-encoding.php">Accept-Encoding</a></li>
				  <li><a href="accept.php">Accept</a></li>
				  <li><a href="referer.php">Referer</a></li>
				  <li><a href="content-legenth.php">Content-Length</a></li>
				  <li><a href="setcookie.php">setcookie</a></li>
				  <li><a href="authenticate.php">Authenticate</a></li>
				</ol>
				
				
            </div>
        </div>
    </div>
    <script src='js/jquery.min.js'></script>
</body>

</html>