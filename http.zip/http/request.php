<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>HTTP Lab.</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <br>
    <br>
    <br>
    <div id='browser'>
        <div id='browser-bar'>
            <div class='circles'></div>
            <div class='circles'></div>
            <div class='circles'></div>
            <p><b>HTTP Lab.</b></p>
        </div>
        <div id='content'>
            <div id='left'>
                <ul id='location-bar'>
                    <li>
                        <a class='location' href="index.php"><b>Ana Sayfa</b></a>
                    </li>
                    <li>
                        <a class='location' href="get.php"><b>GET Method</b></a>
                    </li>
                    <li>
                        <a class='location' href="post.php"><b>POST Method</b></a>
                    </li>
                </ul>
                <center><img src="images/logo.png" alt="Logo"></center>
				<?php 
				//Host Parametresi 
				echo "Host : ".$_SERVER['HTTP_HOST'];
				echo "<br>";
				echo "Server : ".$_SERVER['SERVER_NAME'];
				echo "<br>";
				//User-Agent Parametresi
				echo "User-Agent : ".$_SERVER['HTTP_USER_AGENT'];
				echo "<br>";
				//Accept-Language Parametresi
				echo "Accept-Language: ".$_SERVER["HTTP_ACCEPT_LANGUAGE"];
				echo "<br>";
				//Accept-Encoding Parametresi
				echo "Accept-Encoding: ".$_SERVER["HTTP_ACCEPT_ENCODING"];
				echo "<br>";
				//Accept Parametresi
				echo "Accept: ".$_SERVER["HTTP_ACCEPT"];
				echo "<br>";
				//Cookie Parametresi
				//echo "foo Bar : ".$_COOKIE['foo'];
				//echo "<br>";
				//echo "Cookie : ".$_COOKIE['PHPSESSID'];
				//echo "<br>";
				//Referer Parametresi
				if (isset($_SERVER['HTTP_REFERER'])) {
				echo "Referer : ".$_SERVER["HTTP_REFERER"];
				echo "<br>";
				}
				//Base64_Decode
				$value="ZXJoYW46ZXJoYW4=";
				echo base64_decode ($value) ;
				echo "<br>";
				//echo "AUTH USER: ".$_SERVER["PHP_AUTH_USER"];
				//echo "<br>";
				//echo "AUTH PW: ".$_SERVER["PHP_AUTH_PW"];
			/*
				// Content-Length Tarayıcı toplam boyutu göstererek kaç byte indirildiğini bildirir 
				header('Content-Type: application/rar');
				header('Content-Length: 1000000');
				header('Content-Disposition: attachment; filename="indir.rar"');
				for ($i = 0; $i < 1000; $i++) {
					echo str_repeat(".",1000);
					usleep(50000);
				}
				//// Content-Length Tarayıcı toplam boyutu bilmediğinden sadece kaç byte indirdiğini bildirir. 
				header('Content-Type: application/rar');
				header('Content-Disposition: attachment; filename="indir.rar"');
				for ($i = 0; $i < 1000; $i++) {
					echo str_repeat(".",1000);
					usleep(50000);
				}
			*/
				setcookie("TestCookie", "3RH4N");
				
				
				?>
            </div>

            <div id='right'>

                <p><b>İLETİŞİM</b></p>
                <p class='other entypo-mail'>
                    <a href='indir.rar'>erhan@3RH4N.com</a>
                </p>
                <p class='other entypo-phone'>(0850) 840 90 94</p>

            </div>
        </div>
    </div>
    <script src='js/jquery.min.js'></script>
</body>

</html>