<?php
	$dbhost = "localhost";
	$dbuser = "root"; //Veritabanı Kullanıcı Adı
	$dbpass = ""; //Veritabanı Şifresi
	$dbname = "http"; //Veritabanı Adı
	if (!@mysql_connect($dbhost, $dbuser, $dbpass)) {
			die("Veritabanına bağlanılamadı...<br>HATA: ".mysql_error());
		}else
			{
				/*echo "Database Connected";*/
				 
			}
	if (!@mysql_select_db($dbname)) {
			die("Veritabanı seçilemedi<br>HATA: ".mysql_error());
		}
	//Karakter setinde problem yaşanmaması amacıyla
	mysql_query("SET NAMES utf8"); 
	mysql_query("SET CHARACTER SET 'utf8'"); 
	mysql_query("SET COLLATION_CONNECTION = 'utf8_general_ci'");
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>URL Lab.</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
	<br>
    <br>
    <br>
    <div id='browser'>
        <div id='browser-bar'>
            <div class='circles'></div>
            <div class='circles'></div>
            <div class='circles'></div>
            <p><b>URL Lab.</b></p>
            <span class='arrow entypo-resize-full'></span>
        </div>
        <div id='content'>
            <div id='left'>
					<ul id='location-bar'>
						<li>
							<a class='location' href="index.php"><b>URL ENCODE</b></a>
						</li>
						<li>
							<a class='location' href="get.php"><b>URL DECODE</b></a>
						</li>
					</ul>
					<b style="color:white;">
					<?php
						if(isset($_GET[ 'action' ])){
							$var = $_GET["var"];
							$var = urlencode($var);
							echo $var;
						}
					?>
					</b>
					
            </div>
			
            <div id='right'>
                <p><b>URL ENCODİNG EXAMPLE</b></p>

                <form action="url.php" method="GET">
                    <input value='Url Encoding' type='text' name="var">
                    <input placeholder='Send' type='submit' name="action" value="submit">
                </form>
            </div>
        </div>
    </div>
    <script src='js/jquery.min.js'></script>
</body>

</html>