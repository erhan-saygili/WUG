<?php
	$dbhost = "localhost";
	$dbuser = "root"; //Veritabanı Kullanıcı Adı
	$dbpass = ""; //Veritabanı Şifresi
	$dbname = "http"; //Veritabanı Adı
	if (!@mysql_connect($dbhost, $dbuser, $dbpass)) {
			die("Veritabanına bağlanılamadı...<br>HATA: ".mysql_error());
		}else
			{
				/*echo "Database Connected";*/
				 
			}
	if (!@mysql_select_db($dbname)) {
			die("Veritabanı seçilemedi<br>HATA: ".mysql_error());
		}
	//Karakter setinde problem yaşanmaması amacıyla
	mysql_query("SET NAMES utf8"); 
	mysql_query("SET CHARACTER SET 'utf8'"); 
	mysql_query("SET COLLATION_CONNECTION = 'utf8_general_ci'");
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>HTTP Lab.</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
	<br>
    <br>
    <br>
    <div id='browser'>
        <div id='browser-bar'>
            <div class='circles'></div>
            <div class='circles'></div>
            <div class='circles'></div>
            <p><b>HTTP Lab.</b></p>
            <span class='arrow entypo-resize-full'></span>
        </div>
        <div id='content'>
            <div id='left'>
                <ul id='location-bar'>
                    <li>
                        <a class='location' href="index.php"><b>Ana Sayfa</b></a>
                    </li>
                    <li>
                        <a class='location' href="get.php"><b>GET Method</b></a>
                    </li>
                    <li>
                        <a class='location' href="post.php"><b>POST Method</b></a>
                    </li>
                </ul>
					<b style="color:white;">
					<?php
						if(isset($_GET[ 'action' ])){
							$user_name	= $_GET["user_name"];
							$password 	= md5($_GET["password"]);
							$sql_check = mysql_query("select * from login where username='".$user_name."' and password='".$password."' ") or die(mysql_error());
							if (mysql_num_rows($sql_check)) {
								echo "Giriş Başarılı...";
							}
							else{
								echo "Giriş Başarısız...";
							}
						}
					?>
					</b>
            </div>
			
            <div id='right'>
                <p><b>GET METHOD EXAMPLE</b></p>

                <form action="get.php" method="GET">
                    <input placeholder='User Name' type='text' name="user_name">
                    <input placeholder='Password' type='password' name="password">
                    <input placeholder='Send' type='submit' name="action" value="submit">
					<br>Username: Admin
					<br>Password:123456789
                </form>
            </div>
        </div>
    </div>
    <script src='js/jquery.min.js'></script>
</body>

</html>